﻿CREATE DATABASE JOIN_ASSIGNMENT
GO
USE JOIN_ASSIGNMENT
GO
-- A->a.Tạo bảng EMPLOYEE.
CREATE TABLE EMPLOYEE
(
	EmpNo		INT PRIMARY KEY,
	EmpName		NVARCHAR(25),
	BirthDay	DATE,
	Email		NVARCHAR(55), 
	DeptNo		INT,
	MgrNo		INT NOT NULL,
	StartDate	DATE,
	Salary		MONEY,
	[Level]		INT CHECK([Level] BETWEEN 1 AND 7),
	[Status]	INT CHECK([Status] BETWEEN 0 AND 2),
	Note		NTEXT
)
GO
-- A->a.Tạo bảng EMP STATUS.
CREATE TABLE EMP_STATUS
(
	StatusNo	INT PRIMARY KEY,
	StatusType	VARCHAR(15)
)
GO
INSERT INTO EMP_STATUS (StatusNo, StatusType)
VALUES
	(0, 'Working'),
	(1, 'Unpaid leave'),
	(2, 'Out')
GO
ALTER TABLE EMPLOYEE 
ADD FOREIGN KEY(Status) REFERENCES EMP_STATUS(StatusNo)
GO
-- A->a.Tạo bảng SKILL.
CREATE TABLE SKILL
(
	SkillNo		INT IDENTITY(1,1) PRIMARY KEY,
	SkillName	NVARCHAR(15),
	Note		NTEXT
)
GO
-- A->a.Tạo bảng DEPARTMENT.
CREATE TABLE DEPARTMENT
(
	DeptNo		INT IDENTITY(1, 1) PRIMARY KEY,
	DeptName	NVARCHAR(25),
	Location	NTEXT,
	Note		NTEXT
)
GO
-- A->a.Tạo bảng EMP SKILL.
CREATE TABLE EMP_SKILL
(
	SkillNo		INT FOREIGN KEY REFERENCES SKILL(SkillNo),
	EmpNo		INT FOREIGN KEY REFERENCES EMPLOYEE(EmpNo),
	SkillLevel	INT CHECK (SkillLevel BETWEEN 1 AND 3),
	RegDate		DATE,
	Description NTEXT,
	PRIMARY KEY(SkillNo, EmpNo)
)
GO
-- A->a.Thêm ít nhất 8 bản ghi vào mỗi bảng đã tạo.
INSERT INTO DEPARTMENT(DeptName, Location,  Note)
VALUES
	('JAVA01', 'HaNoi', NULL),
	('JAVA02', 'HaNoi', NULL),
	('JAVA03', 'DaNang',NULL),
	('JAVA04', 'DaNang',NULL),
	('JAVA05', 'CanTho', NULL),
	('JAVA06', 'CanTho', NULL),
	('JAVA07', 'HCMCity', NULL),
	('JAVA08', 'HCMCity', NULL)
GO

 INSERT EMPLOYEE(EmpNo, EmpName, BirthDay, Email, DeptNo, MgrNo, StartDate, Salary, [Level], [Status])
 VALUES
		(1, N'Nguyễn Minh Tuấn', '19970421', 'TuanNM89@fsoft.com',  1, 8, '20201110', 0.00, 1, 0 ),
		(2, N'Lại Quốc Việt','19930926', 'VietLQ20@fsoft.com', 2, 7,'20221020', 0.00, 2, 0  ),
		(3, N'Vũ Nhật Quang','19960508', 'QuangVN5@fsoft.com', 3, 5, '20220210', 0.00, 3, 0),
		(4, N'Nguyễn Minh Hiếu', '19990817', 'HieuNM83@fsoft.com', 4, 6, '20210521',0.00, 4, 0),
		(5, N'Vũ Mai Anh', '20021031', 'AnhVN7@fsoft.com', 5, 2, '20210411', 0.00, 5, 0),
		(6, N'Phạm Quỳnh Phú', '20000504', 'PhuPQ1@fpt.com', 6, 3, '20220615', 0.00, 6, 0),
		(7, N'Kiều Đình Quân', '20021031', 'QuanKD@fpt.com', 7, 4, '20210121', 0.00, 7, 0),
		(8, N'Lương Việt Hoàng', '19960726', 'HoangLV26@fpt.com', 8, 1, '20221211', 0.00, 1, 0)
 GO

INSERT INTO SKILL(SkillName, Note)
VALUES
	('JavaBase', NULL),
	('.NET', NULL),
	('C++', NULL),
	('C#', NULL),
	('PYTHON', NULL),
	('JAVA', NULL),
	('PHP', NULL),
	('JavaScript', NULL)
GO

INSERT INTO EMP_SKILL(SkillNo, EmpNo, SkillLevel, RegDate)
VALUES
	(1, 1, 1, '20180102'),
	(2, 2, 2, '20190304'),
	(3, 3, 3, '20200506'),
	(4, 4, 1, '20210708'),
	(5, 5, 1, '20210910'),
	(6, 6, 2, '20200910'),
	(7, 7, 1, '20221112'),
	(8, 8, 3, '20200510')
GO
-- B-> .Ghi rõ họ tên, email, cấp bậc và tên bộ phận của nhân viên đã làm việc ít nhất 1 năm.
SELECT E.EmpName, E.Email, E.Level, E.StartDate, D.DeptName
FROM EMPLOYEE AS E
JOIN DEPARTMENT AS D 
ON E.DeptNo = D.DeptNo
WHERE E.StartDate < DATEADD(YEAR, -1, GETDATE())
GO
-- C-> .Chỉ định tên của những nhân viên có kỹ năng 'C ++' và '.NET'.
SELECT e.EmpName
FROM EMPLOYEE AS E
JOIN EMP_SKILL ES 
ON E.EmpNo = ES.EmpNo
JOIN SKILL AS S 
ON ES.SkillNo = S.SkillNo
WHERE s.SkillName IN ('C++', '.NET')
GROUP BY E.EmpName
HAVING COUNT(DISTINCT S.SkillName) = 2
GO
-- D-> .Liệt kê tất cả tên nhân viên, email nhân viên, tên người quản lý, email người quản lý của những nhân viên đó.
SELECT E1.EmpName, E1.Email, E2.EmpName AS ManagerName, E2.Email AS ManagerEmail
FROM EMPLOYEE E1
JOIN EMPLOYEE E2 
ON E1.MgrNo = E2.EmpNo
GO
-- E-> .Chỉ định các bộ phận không có bất kỳ nhân viên nghỉ không lương nào và in số lượng nhân viên được sắp xếp giảm dần.
SELECT D.DeptName, COUNT(*) AS NumberOfEmployees
FROM DEPARTMENT AS D
JOIN EMPLOYEE AS E 
ON D.DeptNo = E.DeptNo
WHERE E.Status != 1
GROUP BY D.DeptName
ORDER BY NumberOfEmployees DESC
GO
-- F-> .Liệt kê tất cả tên, email và số kỹ năng của nhân viên đang làm việc và sắp xếp thứ tự tăng dần theo tên của nhân viên.
SELECT E.EmpName, E.Email, ES.SkillNo
FROM EMPLOYEE AS E
JOIN EMP_SKILL ES 
ON E.EmpNo = ES.EmpNo
WHERE E.Status = 0
ORDER BY E.EmpName ASC
GO
-- G-> .Tạo view liệt kê tất cả nhân viên đang làm việc trên Hà Nội (gồm: tên nhân viên và tên kỹ năng, tên phòng ban)
CREATE VIEW VW_HanoiEmployees AS
SELECT E.EmpName, S.SkillName, D.DeptName
FROM EMPLOYEE AS E
JOIN EMP_SKILL AS ES 
ON E.EmpNo = ES.EmpNo
JOIN SKILL AS S 
ON ES.SkillNo = S.SkillNo
JOIN DEPARTMENT AS D 
ON E.DeptNo = D.DeptNo
WHERE D.Location LIKE 'Hanoi' AND E.Status = 0
GO

SELECT * FROM dbo.VW_HanoiEmployees 
GO