package list.linkedlist;

public class LinkedList {

    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();

        linkedList.add(1);
        linkedList.add(2);
        linkedList.add(3);
        System.out.println("After adding: " + linkedList);


        linkedList.add(1, 4);
        System.out.println("After adding at position 1: " + linkedList);

        linkedList.remove(1);
        System.out.println("After removing at position 1: " + linkedList);
    }

    class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
        }
    }

    Node head;

    Node tail;

    void add(int data) {
        if (head == null) {
            head = new Node(data);
            tail = head;
            return;
        }
        tail.next = new Node(data);
        tail = tail.next;
    }

    void add(int pos, int data) {
        Node newNode = new Node(data);
        if (pos == 0) {
            head = newNode;
            tail = head;
            return;
        }
        Node curr = head;
        for (int i = 0; i < pos - 1 && curr != null; i++) {
            curr = curr.next;
        }
        if (curr != null) {
            newNode.next = curr.next;
            curr.next = newNode;
        }
    }

    void remove(int pos) {
        if (pos == 0) {
            head = head.next;
            return;
        }
        Node curr = head;
        for (int i = 0; i < pos - 1 && curr != null; i++) {
            curr = curr.next;
        }
        if (curr != null) {
            curr.next = curr.next.next;
        }
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        boolean firstElement = true;
        Node curr = head;

        sb.append("[");
        while (curr.next != null) {
            if (!firstElement) {
                sb.append(", ");
            }
            sb.append(curr.data);
            if (firstElement) {
                firstElement = false;
            }
            curr = curr.next;
        }
        sb.append("]");

        return sb.toString();
    }
}
