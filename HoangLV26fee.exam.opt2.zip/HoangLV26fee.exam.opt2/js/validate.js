function isEmail(inputemail)
{
        var emailPat=/^(.+)@(.+)$/;
        var specialChars="\\(\\)<>@,;:\\\\\\\"\\.\\[\\]";
        var validChars="\[^\\s" + specialChars + "\]";
        var quotedUser="(\"[^\"]*\")"
        var ipDomainPat=/^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/;
        var atom=validChars + '+';
        var word="(" + atom + "|" + quotedUser + ")";
        var userPat=new RegExp("^" + word + "(\\." + word + ")*$");
        var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$");
        var matchArrayEmail=inputemail.match(emailPat);
        if (matchArrayEmail==null) {
                return false;
        }
        var user=matchArrayEmail[1];
        var domain=matchArrayEmail[2];
        if (user.match(userPat)==null) {
            return false;
        }
        var IPArray=domain.match(ipDomainPat);
        if (IPArray!=null) {
                  for (var i=1;i<=4;i++) {
                    if (IPArray[i]>255) {
                        return false;
                    }
            }
            return true;
        }
        var domainArray=domain.match(domainPat);
        if (domainArray==null) {
            return false;
        }
        var atomPat=new RegExp(atom,"g");
        var domArr=domain.match(atomPat);
        var len=domArr.length;
        if (domArr[domArr.length-1].length<2 ||
            domArr[domArr.length-1].length>3) {
           return false;
        }
        if (len<2)
        {
           return false;
        }
        return true;
}

function isPhone(inputPhone){
var PhonePat = /^\d{3}-\d{3}-\d{7}$/;
var matchArrayphone=inputPhone.match(PhonePat);
if (matchArrayphone==null) {
    return false;
}
return true;
}

$(document).ready(function(){
    $('#reset-btn').click(function(){
        location.reload();
    })
})
$(document).ready(function(){
    $('input[type="file"]').change(function(e){
      var fileName = e.target.files[0].name;
      $('.custom-file-label').html(fileName);
    });
  });
$(document).ready(function () {
    $('#sendButton').click(function (){
        var firstname = $.trim($('#FirstName').val());
        var lastname = $.trim($('#LastName').val());
        var email = $.trim($('#Email').val());
        var phone = $.trim($('#Phone').val())
        var country = $('#country').val();
        var position = $('#position').val();
        var flag = true;
        if (firstname == '') {
            $('#FirstNameVal').text('Tên đăng nhập không được để trống');
            flag = false;
        }
        else {
            $('#FirstNameVal').text('');
        }
        if (lastname == '') {
            $('#LastNameVal').text('Bạn phải nhập mật khẩu');
            flag = false;
        }
        else {
            $('#LastNameVal').text('');
        }
        if (!isEmail(email)){
            $('#emailVal').text('Email không được để trống và phải đúng định dạng');
            flag = false;
        }
        else{
            $('#emailVal').text('');
        }
        if(!isPhone(phone)){
            $('#PhoneVal').text('Số điện thoại phải nhập theo định dạng ###-###-#######');
        }else{
            $('#PhoneVal').text('');
        }
        
        if (country == "Select country") {
            $('#countryVal').text('Bạn bắt buộc phải lựa chọn thành phố sinh sống');

        }else{
            $('#countryVal').text('asdas');
            
        }
        if (position=="Choose desired position") {
            $('#PositionVal').text('Bạn bắt buộc phải lựa chọn vị trí ứng tuyển');
        }else{
            $('#PositionVal').text('');
        }

        return flag;
    });
});

