package list.linkedlist;

import java.util.Arrays;

public class MyArrays {
    public static void main(String[] args) {
        int[] arr = new int[100];
        int n = 0;

        for(int i = 0; i < 20; i++){
            arr[i] = i;
            n++;
        }

        insert(arr, n,1, 21 );
        n++;

        delete(arr, n, 1);
        n--;

        for(int i = 0; i < n;i++){
            System.out.print(arr[i] + " ");
        }
    }

    public static void insert(int[] arr, int n, int pos, int data){
        for (int i = n; i >= pos; i--){
            arr[i] = arr[i-1];
        }
        arr[pos] = data;
    }

    public static void delete(int[] arr, int n, int pos){
        for(int i = pos; i < n; i++){
            arr[i] = arr[i+1];
        }

    }
}
