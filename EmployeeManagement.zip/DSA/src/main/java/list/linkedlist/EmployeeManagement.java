package list.linkedlist;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class EmployeeManagement {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MyLinkedList employees = new MyLinkedList();
        int choice = -1;

        while (choice != 0){
            showMenu();
            System.out.println("Your choice: ");
            choice = Integer.parseInt(scanner.nextLine());
            switch (choice){
                case 1:
                    Employee employee = new Employee();

                    System.out.println("Id: ");
                    employee.id = Integer.parseInt(scanner.nextLine());

                    System.out.println("Name: ");
                    employee.name = scanner.nextLine();

                    System.out.println("Score: ");
                    employee.score = Float.parseFloat(scanner.nextLine());

                    employees.add(employee);

                    break;
                case 2:
                    System.out.println(employees);
                    break;
                case 3:
                    break;
                case 4:
                    break;
                case 5:
                    break;
                case 0:
                    System.out.println("Exit");
                    break;
                default:
                    System.err.println("Invalid choice!");
                    break;
            }
        }
    }

    public static void showMenu(){
        System.out.println("========= Employee Management System =========");
        System.out.println("1. Add employee");
        System.out.println("2. Display all employees");
        System.out.println("3. Search by id");
        System.out.println("4. Update employee");
        System.out.println("5. Delete employee");
        System.out.println("0. Exit");
    }
}
