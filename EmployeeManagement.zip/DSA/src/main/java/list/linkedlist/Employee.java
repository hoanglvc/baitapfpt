package list.linkedlist;

public class Employee {

    int id;

    String name;

    float score;

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", score=" + score +
                '}';
    }
}
