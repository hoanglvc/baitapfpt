package list.linkedlist;

public class MyLinkedList {

    public static void main(String[] args) {
        MyLinkedList linkedList = new MyLinkedList();

        Employee employee = new Employee();
        employee.id = 1;
        linkedList.add(employee);

        System.out.println("After adding: " + linkedList);


        linkedList.add(1, employee);
        System.out.println("After adding at position 1: " + linkedList);

        linkedList.remove(1);
        System.out.println("After removing at position 1: " + linkedList);
    }

    class Node {
        Employee data;
        Node next;

        Node(Employee data) {
            this.data = data;
        }
    }

    Node head;

    Node tail;

    void add(Employee data) {
        if (head == null) {
            head = new Node(data);
            tail = head;
            return;
        }
        tail.next = new Node(data);
        tail = tail.next;
    }

    void add(int pos, Employee data) {
        Node newNode = new Node(data);
        if (pos == 0) {
            head = newNode;
            tail = head;
            return;
        }
        Node curr = head;
        for (int i = 0; i < pos - 1 && curr != null; i++) {
            curr = curr.next;
        }
        if (curr != null) {
            newNode.next = curr.next;
            curr.next = newNode;
        }
    }

    void remove(int pos) {
        if (pos == 0) {
            head = head.next;
            return;
        }
        Node curr = head;
        for (int i = 0; i < pos - 1 && curr != null; i++) {
            curr = curr.next;
        }
        if (curr != null) {
            curr.next = curr.next.next;
        }
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        boolean firstElement = true;
        Node curr = head;

        sb.append("[");
        while (curr != null) {
            if (!firstElement) {
                sb.append(", ");
            }
            sb.append(curr.data);
            if (firstElement) {
                firstElement = false;
            }
            curr = curr.next;
        }
        sb.append("]");

        return sb.toString();
    }
}
