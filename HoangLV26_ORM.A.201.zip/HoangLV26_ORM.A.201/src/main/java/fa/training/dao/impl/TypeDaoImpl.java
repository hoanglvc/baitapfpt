package fa.training.dao.impl;

import fa.training.dao.TypeDao;
import fa.training.entities.Type;

public class TypeDaoImpl extends BaseDaoImpl<Type, Integer> implements TypeDao{

	public TypeDaoImpl() {
		super(Type.class);
	}

}
