package fa.training.dao;

import fa.training.entities.Type;

public interface TypeDao extends BaseDao<Type, Integer> {

}
