package fa.training.dao;

import java.io.Serializable;
import java.util.List;

public interface BaseDao<E, ID extends Serializable >{
	public E insert(E e);
	public boolean updateById(E e);
	public boolean deleteById(ID id);
	public E getById(ID id);
	public List<E> getAll();
}
