package fa.training.dao;

import fa.training.entities.MovieType;

public interface MovieTypeDao extends BaseDao<MovieType, Integer>{
	boolean deleteById(Integer id1, String id2);
	MovieType getById(Integer id1, String id2);
}
