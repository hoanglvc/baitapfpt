package fa.training.dao.impl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import fa.training.dao.MovieDao;
import fa.training.entities.Movie;
import fa.training.util.HibernateUtil;

public class MovieDaoImpl extends BaseDaoImpl<Movie, Integer> implements MovieDao{
	
	public MovieDaoImpl() {
		super(Movie.class);
	}

	@Override
	public Movie getByIdMovie(String id) {
		Movie movie;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			session.beginTransaction();
			movie = session.get(Movie.class, id);
			session.getTransaction().commit();
		}
		return movie;
	}

	@Override
	public boolean deleteById(String id) {
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			session.beginTransaction();
			Movie movie = session.get(Movie.class, id);
			session.delete(movie);
			session.getTransaction().commit();
		}
		return true;
	}

}
