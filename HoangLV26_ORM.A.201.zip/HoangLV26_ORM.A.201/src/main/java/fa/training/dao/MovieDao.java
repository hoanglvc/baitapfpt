package fa.training.dao;

import fa.training.entities.Movie;

public interface MovieDao extends BaseDao<Movie, Integer>{
	Movie getByIdMovie(String id);
	boolean deleteById(String id);
}

