package fa.training.dao.impl;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import fa.training.dao.BaseDao;
import fa.training.util.HibernateUtil;

public abstract class BaseDaoImpl<E, ID extends Serializable> implements BaseDao<E, ID> {

	private Class<E> typeEntity;
	private SessionFactory sessionFactory;

	public BaseDaoImpl(Class<E> typeEntity) {
		this.typeEntity = typeEntity;
		this.sessionFactory = HibernateUtil.getSessionFactory();
	}

	@Override
	public E insert(E e) {
		try (Session session = sessionFactory.openSession()) {
			session.beginTransaction();
			session.save(e);
			session.getTransaction().commit();
			return e;
		}
	}

	@Override
	public boolean updateById(E e) {
		try (Session session = sessionFactory.openSession()) {
			session.beginTransaction();
			session.update(e);
			session.getTransaction().commit();
			return true;
		}
	}

	@Override
	public boolean deleteById(ID id) {
		try (Session session = sessionFactory.openSession()) {
			session.beginTransaction();
			E e = session.get(typeEntity, id);
			session.delete(e);
			session.getTransaction().commit();
			return true;
		}
	}

	@Override
	public E getById(ID id) {
		try (Session session = sessionFactory.openSession()) {
			session.beginTransaction();
			E e = session.get(typeEntity, id);
			session.getTransaction().commit();
			return e;
		}
	}

	@Override
	public List<E> getAll() {
		try (Session session = sessionFactory.openSession()) {
			session.beginTransaction();
			Query<E> query = session.createQuery("from " + typeEntity.getSimpleName(), typeEntity);
			session.getTransaction().commit();
			return query.getResultList();
		}

	}
}
