package fa.training.dao.impl;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.query.Query;

import fa.training.dao.MovieTypeDao;
import fa.training.entities.MovieType;
import fa.training.util.HibernateUtil;

public class MovieTypeDaoImpl extends BaseDaoImpl<MovieType, Integer> implements MovieTypeDao{

	public MovieTypeDaoImpl() {
		super(MovieType.class);
	}

	@Override
	public boolean deleteById(Integer id1, String id2) {
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			session.beginTransaction();
			MovieType movieType = getById(id1, id2);
			session.delete(movieType);
			session.getTransaction().commit();
			return true;
		}
	}

	@Override
	public MovieType getById(Integer id1, String id2) {
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			session.beginTransaction();
			TypedQuery<MovieType> query = session.createQuery("from MovieType where movieTypeId.movie.id = :movieId and movieTypeId.type.id = :typeId", MovieType.class);
			query.setParameter("typeId", id1);
			query.setParameter("movieId", id2);
			session.getTransaction().commit();
			return query.getSingleResult();
		}
	}

}
