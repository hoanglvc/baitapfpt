package fa.training.entities;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "MOVIE")
public class Movie {

	@Id
	@Column(name = "MOVIE_ID", columnDefinition = "varchar(10)")
	private String id;
	
	@Column(name = "ACTOR", nullable = false)
	private String actor;
	
	@Column(name = "CONTENT", length = 1000, nullable = false)
	private String content;
	
	@Column(name = "DIRECTOR", nullable = false)
	private String director;
	
	@Column(name = "DURATION", nullable = false, precision = 5, scale = 2)
	private Double duration;
	
	@Column(name = "FORM_DATE", nullable = false)
	private LocalDate formDate;
	
	@Column(name = "TO_DATE", nullable = false)
	private LocalDate toDate;
	
	@Column(name = "MOVIE_PRODUCTION_COMPANY", nullable = false)
	private String movieProductionCompany;
	
	@Column(name = "VERSION", nullable = false)
	private String version;
	
	@Column(name = "MOVIE_NAME_ENG", unique = true, nullable = false)
	private String movieNameEng;
	
	@Column(name = "MOVIE_NAME_VN", unique = true, nullable = false)
	private String movieNameVn;
	
	@Column(name = "LARGE_IMAGE", nullable = false)
	private String lagerImage;
	
	@Column(name = "SMALL_IMAGE", nullable = false)
	private String smallImage;
	
	@OneToMany(mappedBy = "movieTypeId.movie", cascade = CascadeType.ALL)
	private List<MovieType> movieTypes;

	public Movie() {
	}

	public Movie(String movieId, String actor, String content, String director, Double duration, LocalDate formDate,
			LocalDate toDate, String movieProductionCompany, String version, String movieNameEng, String movieNameVn,
			String lagerImage, String smallImage) {
		this.id = movieId;
		this.actor = actor;
		this.content = content;
		this.director = director;
		this.duration = duration;
		this.formDate = formDate;
		this.toDate = toDate;
		this.movieProductionCompany = movieProductionCompany;
		this.version = version;
		this.movieNameEng = movieNameEng;
		this.movieNameVn = movieNameVn;
		this.lagerImage = lagerImage;
		this.smallImage = smallImage;
	}

	public String getMovieId() {
		return id;
	}

	public void setMovieId(String movieId) {
		this.id = movieId;
	}

	public String getActor() {
		return actor;
	}

	public void setActor(String actor) {
		this.actor = actor;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public Double getDuration() {
		return duration;
	}

	public void setDuration(Double duration) {
		this.duration = duration;
	}

	public LocalDate getFormDate() {
		return formDate;
	}

	public void setFormDate(LocalDate formDate) {
		this.formDate = formDate;
	}

	public LocalDate getToDate() {
		return toDate;
	}

	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}

	public String getMovieProductionCompany() {
		return movieProductionCompany;
	}

	public void setMovieProductionCompany(String movieProductionCompany) {
		this.movieProductionCompany = movieProductionCompany;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getMovieNameEng() {
		return movieNameEng;
	}

	public void setMovieNameEng(String movieNameEng) {
		this.movieNameEng = movieNameEng;
	}

	public String getMovieNameVn() {
		return movieNameVn;
	}

	public void setMovieNameVn(String movieNameVn) {
		this.movieNameVn = movieNameVn;
	}

	public String getLagerImage() {
		return lagerImage;
	}

	public void setLagerImage(String lagerImage) {
		this.lagerImage = lagerImage;
	}

	public String getSmallImage() {
		return smallImage;
	}

	public void setSmallImage(String smallImage) {
		this.smallImage = smallImage;
	}
}
