package fa.training.entities;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "MOVIE_TYPE")
public class MovieType {
	
	@EmbeddedId
	private MovieTypeId movieTypeId;
	
	@Column(name = "MT_DESCRIPTION", nullable = false)
	private String mtDescription;


	public MovieTypeId getMovieTypeId() {
		return movieTypeId;
	}

	public void setMovieTypeId(MovieTypeId movieTypeId) {
		this.movieTypeId = movieTypeId;
	}

	public String getMtDescription() {
		return mtDescription;
	}

	public void setMtDescription(String mtDescription) {
		this.mtDescription = mtDescription;
	}
	
}