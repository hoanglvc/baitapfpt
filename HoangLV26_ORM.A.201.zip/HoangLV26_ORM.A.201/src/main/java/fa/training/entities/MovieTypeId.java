package fa.training.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;

@Embeddable
public class MovieTypeId implements Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	
	@ManyToOne
	@JoinColumn(name = "TYPE_ID")
	private Type type;
	
	@ManyToOne
	@JoinColumn(name = "MOVIE_ID", columnDefinition = "varchar(10)")
	private Movie movie;

	@Override
	public int hashCode() {
		return Objects.hash(movie, type);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MovieTypeId other = (MovieTypeId) obj;
		return Objects.equals(movie, other.movie) && Objects.equals(type, other.type);
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}
	
	
}
