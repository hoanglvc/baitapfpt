package fa.training.entities;

import java.util.Set; 

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "TYPE")
public class Type {

	@Id
	@Column(name = "TYPE_ID")
	private Integer id;

	@Column(name = "TYPE_NAME", nullable = false, unique = true)
	private String column;
	
	@Column(name = "TYPE_DESCRIPTION", nullable = false)
	private String typeDescription;
	
	@OneToMany(mappedBy = "movieTypeId.type")
	private Set<MovieType> types;

	public Type(Integer typeId, String column, String typeDescription) {
		this.id = typeId;
		this.column = column;
		this.typeDescription = typeDescription;
	}

	public Type() {
	}

	public Integer getTypeId() {
		return id;
	}

	public void setTypeId(Integer typeId) {
		this.id = typeId;
	}

	public String getColumn() {
		return column;
	}

	public void setColumn(String column) {
		this.column = column;
	}

	public String getTypeDescription() {
		return typeDescription;
	}

	public void setTypeDescription(String typeDescription) {
		this.typeDescription = typeDescription;
	}

	public Set<MovieType> getTypes() {
		return types;
	}

	public void setTypes(Set<MovieType> types) {
		this.types = types;
	}
}
