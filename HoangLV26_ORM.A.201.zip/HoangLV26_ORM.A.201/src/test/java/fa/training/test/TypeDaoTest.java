package fa.training.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;


import org.junit.Before;
import org.junit.Test;

import fa.training.dao.impl.TypeDaoImpl;
import fa.training.entities.Type;

public class TypeDaoTest {
	TypeDaoImpl typeDaoImpl;

	@Before
	public void setUp() {
		typeDaoImpl = new TypeDaoImpl();
	}

	@Test
	public void testSave() {
		Type type = new Type();
		type.setTypeId(1);
		type.setColumn("C");
		type.setTypeDescription("Test");
		
		assertEquals(type, typeDaoImpl.insert(type));
	}
	
	@Test
	public void testGetById() {
		assertEquals((Integer)1, typeDaoImpl.getById(1). getTypeId());
	}
	
	@Test
	public void testUpdate() {
		Type type = new Type();
		type.setTypeId(1);
		type.setColumn("HieuNguyen");
		type.setTypeDescription("Test");
		
		assertTrue(typeDaoImpl.updateById(type));
	}
	
	@Test
	public void testGetAll() {
		assertNotNull(typeDaoImpl.getAll());
	}
	
	@Test 
	public void testDelete() {
		assertTrue(typeDaoImpl.deleteById(1));
	}
}
