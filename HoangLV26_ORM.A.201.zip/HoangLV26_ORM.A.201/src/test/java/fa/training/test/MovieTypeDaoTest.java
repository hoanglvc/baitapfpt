package fa.training.test;

import fa.training.dao.impl.MovieTypeDaoImpl; 
import fa.training.entities.Movie;
import fa.training.entities.MovieType;
import fa.training.entities.MovieTypeId;
import fa.training.entities.Type;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;

public class MovieTypeDaoTest {
	MovieTypeDaoImpl movieTypeDaoImpl;

	@Before
	public void setUp() {
		movieTypeDaoImpl = new MovieTypeDaoImpl();
	}

	@Test
	public void testSave() {
		MovieTypeId movieTypeId = new MovieTypeId();
		Movie movie = new Movie();
		movie.setActor("HieuNguyen");
		movie.setContent("Test");
		movie.setDirector("Test");
		movie.setDuration(1d);
		movie.setFormDate(LocalDate.now());
		movie.setLagerImage("Test");
		movie.setMovieId("B");
		movie.setMovieNameEng("Test");
		movie.setMovieNameVn("Test");
		movie.setMovieProductionCompany("Test");
		movie.setSmallImage("Test");
		movie.setVersion("Test");
		movie.setToDate(LocalDate.now());
		
		MovieType movieType = new MovieType();
		Type type = new Type();
		type.setTypeId(1);
		type.setColumn("HieuNguyen");
		type.setTypeDescription("Test");
		
		movieTypeId.setMovie(movie);
		movieTypeId.setType(type);
		movieType.setMovieTypeId(movieTypeId);
		movieType.setMtDescription("Test");
		
		assertEquals(movieType, movieTypeDaoImpl.insert(movieType));
	}
	
	@Test
	public void testGetById() {
		assertEquals("HieuNguyen", movieTypeDaoImpl.getById(1,"B").getMtDescription());
	}
	
	@Test
	public void testUpdate() {
		MovieTypeId movieTypeId = new MovieTypeId();
		MovieType movieType = new MovieType();
		Movie movie = new Movie();
		movie.setMovieId("B");
		
		Type type = new Type();
		type.setTypeId(1);
		
		movieTypeId.setMovie(movie);
		movieTypeId.setType(type);
		movieType.setMovieTypeId(movieTypeId);
		movieType.setMtDescription("Ahihi");
		
		assertTrue(movieTypeDaoImpl.updateById(movieType));
	}
	
	@Test
	public void testGetAll() {
		assertNotNull(movieTypeDaoImpl.getAll());
	}
	
	@Test 
	public void testDelete() {
		assertTrue(movieTypeDaoImpl.deleteById(1,"B"));
	}
}

