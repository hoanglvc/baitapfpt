package fa.training.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;

import fa.training.dao.impl.MovieDaoImpl;
import fa.training.entities.Movie;

public class MovieDaoTest {
	MovieDaoImpl movieDaoImpl;

	@Before
	public void setUp() {
		movieDaoImpl = new MovieDaoImpl();
	}

	@Test
	public void testSave() {
		Movie movie = new Movie();
		movie.setActor("A");
		movie.setContent("Test");
		movie.setDirector("Test");
		movie.setDuration(1d);
		movie.setFormDate(LocalDate.now());
		movie.setLagerImage("Test");
		movie.setMovieId("B");
		movie.setMovieNameEng("Test");
		movie.setMovieNameVn("Test");
		movie.setMovieProductionCompany("Test");
		movie.setSmallImage("Test");
		movie.setVersion("Test");
		movie.setToDate(LocalDate.now());
		
		assertEquals(movie, movieDaoImpl.insert(movie));
	}
	
	@Test
	public void testGetById() {
		assertEquals("B", movieDaoImpl.getByIdMovie("B").getMovieId());
	}
	
	@Test
	public void testUpdate() {
		Movie movie = new Movie();
		movie.setActor("HieuNguyen");
		movie.setContent("Test");
		movie.setDirector("Test");
		movie.setDuration(1d);
		movie.setFormDate(LocalDate.now());
		movie.setLagerImage("Test");
		movie.setMovieId("B");
		movie.setMovieNameEng("Test");
		movie.setMovieNameVn("Test");
		movie.setMovieProductionCompany("Test");
		movie.setSmallImage("Test");
		movie.setVersion("Test");
		movie.setToDate(LocalDate.now());
		
		assertTrue(movieDaoImpl.updateById(movie));
	}
	
	@Test
	public void testGetAll() {
		assertNotNull(movieDaoImpl.getAll());
	}
	
	@Test 
	public void testDelete() {
		assertTrue(movieDaoImpl.deleteById("B"));
	}
}
