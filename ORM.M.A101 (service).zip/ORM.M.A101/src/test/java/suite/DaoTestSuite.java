package suite;

import fa.training.dao.CinemaRoomDaoTest;
import fa.training.dao.CinemaRoomDetailDaoTest;
import fa.training.dao.SeatDaoTest;
import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({CinemaRoomDaoTest.class, CinemaRoomDetailDaoTest.class, SeatDaoTest.class})
public class DaoTestSuite {
}
