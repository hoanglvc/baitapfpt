package fa.training.dao;

import fa.training.dao.impl.CinemaRoomDaoImpl;
import fa.training.entities.CinemaRoom;
import static org.junit.jupiter.api.Assertions.*;
import org.hibernate.exception.ConstraintViolationException;
import org.junit.jupiter.api.*;

import java.util.Arrays;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class CinemaRoomDaoTest {

    static CinemaRoomDao cinemaRoomDao;

    @BeforeAll
    static void beforeAll(){
        cinemaRoomDao = new CinemaRoomDaoImpl();
    }

    @Order(1)
    @Test
    public void testSaveCinemaRoomSuccess() {
        CinemaRoom cgv = CinemaRoom.builder()
                .cinemaRoomName("CGV")
                .seatQuantity(12)
                .build();

        CinemaRoom lotte = CinemaRoom.builder()
                .cinemaRoomName("Lotte")
                .seatQuantity(20)
                .build();


        assertAll(
                ()->assertNotNull(cinemaRoomDao.save(cgv)),
                ()->assertNotNull(cinemaRoomDao.save(lotte))
        );
    }


    @Order(3)
    @Test
    public void testSaveCinemaRoomDuplicateNameFailed(){
        CinemaRoom cinemaRoom = CinemaRoom.builder()
                .cinemaRoomName("CGV")
                .seatQuantity(12)
                .build();
        assertThrows(ConstraintViolationException.class, () -> cinemaRoomDao.save(cinemaRoom));
    }

    @Order(6)
    @Test
    public void testGetOne(){
        assertEquals("CGV", cinemaRoomDao.getOne(1).getCinemaRoomName());
    }

    @Order(8)
    @Test
    public void testUpdateSuccess(){
        CinemaRoom cinemaRoom = CinemaRoom.builder()
                .cinemaRoomId(1)
                .cinemaRoomName("CGV")
                .seatQuantity(12)
                .build();
        cinemaRoomDao.update(cinemaRoom);
        assertEquals("CGV", cinemaRoomDao.getOne(1).getCinemaRoomName());
    }

    //disable to test save cinema room detail and seat with room id 1
    @Order(9)
    @Test
    public void testDeleteSuccess(){
        cinemaRoomDao.delete(2);
        assertNull(cinemaRoomDao.getOne(2));
    }


}
