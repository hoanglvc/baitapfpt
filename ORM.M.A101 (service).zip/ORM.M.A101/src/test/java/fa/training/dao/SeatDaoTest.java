package fa.training.dao;

import fa.training.dao.impl.CinemaRoomDaoImpl;
import fa.training.dao.impl.SeatDaoImpl;
import fa.training.entities.CinemaRoom;
import fa.training.entities.Seat;
import fa.training.enums.SeatStatus;
import fa.training.enums.SeatType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class SeatDaoTest {

    static CinemaRoomDao cinemaRoomDao = new CinemaRoomDaoImpl();
    static SeatDao seatDao = new SeatDaoImpl();

    @BeforeAll
    static void beforeAll(){
        cinemaRoomDao = new CinemaRoomDaoImpl();
        seatDao = new SeatDaoImpl();

    }

    @Test
    public void testSaveSeatSuccess(){
        Seat seat = Seat.builder()
                .seatColumn("A")
                .seatRow("8")
                .seatType(SeatType.VIP)
                .seatStatus(SeatStatus.AVAILABLE)
                .cinemaRoom(cinemaRoomDao.getOne(1))
                .build();

        assertNotNull(seatDao.save(seat));
    }
}
