package fa.training.dao;

import fa.training.dao.impl.CinemaRoomDaoImpl;
import fa.training.dao.impl.CinemaRoomDetailDaoImpl;
import fa.training.entities.CinemaRoom;
import fa.training.entities.CinemaRoomDetail;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

public class CinemaRoomDetailDaoTest {

    static CinemaRoomDao cinemaRoomDao;
    static CinemaRoomDetailDao cinemaRoomDetailDao;

    @BeforeAll
    static void beforeAll(){
        cinemaRoomDao = new CinemaRoomDaoImpl();
        cinemaRoomDetailDao = new CinemaRoomDetailDaoImpl();
    }

    @Test
    public void testSaveDetailSuccess(){
        CinemaRoomDetail cinemaRoomDetail = CinemaRoomDetail.builder()
                .roomRate(2)
                .activeDate(LocalDate.now().minusYears(1))
                .roomDescription("")
                .cinemaRoom(cinemaRoomDao.getOne(1))
                .build();

        assertNotNull(cinemaRoomDetailDao.save(cinemaRoomDetail));
    }
}

