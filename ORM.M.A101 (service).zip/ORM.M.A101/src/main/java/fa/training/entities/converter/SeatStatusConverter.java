package fa.training.entities.converter;

import fa.training.enums.SeatStatus;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class SeatStatusConverter implements AttributeConverter<SeatStatus, String> {

    @Override
    public String convertToDatabaseColumn(SeatStatus seatStatus) {
        switch (seatStatus){
            case AVAILABLE:
                return "Available";
            case NOT_AVAILABLE:
                return "Not Available";
            case BOOKED:
                return "Booked";
            default:
                return null;
        }
    }

    @Override
    public SeatStatus convertToEntityAttribute(String s) {
        switch (s){
            case "Available":
                return SeatStatus.AVAILABLE;
            case "Not Available":
                return SeatStatus.NOT_AVAILABLE;
            case "Booked":
                return SeatStatus.BOOKED;
            default:
                return null;
        }
    }
}
