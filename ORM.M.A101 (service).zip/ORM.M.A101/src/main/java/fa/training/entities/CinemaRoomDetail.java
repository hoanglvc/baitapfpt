package fa.training.entities;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;

@Getter
@Setter
@ToString
@Entity
@Table(name="CINEMA_ROOM_DETAIL")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CinemaRoomDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="CINEMA_ROOM__DETAIL_ID")
    private Integer cinemaRoomDetailId;

    @Column(name="ROOM_RATE",nullable = false)
    private Integer roomRate;

    @Column(name="ACTIVE_DATE",nullable = false)
    private LocalDate activeDate;

    @Column(name="ROOM_DESCRIPTION",nullable = false)
    private String roomDescription;

    @OneToOne
    @JoinColumn(name="CINEMA_ROOM_ID")
    private CinemaRoom cinemaRoom;

}
