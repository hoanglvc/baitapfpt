package fa.training.entities;

import fa.training.enums.SeatType;
import fa.training.entities.converter.SeatTypeConverter;
import lombok.*;
import fa.training.enums.SeatStatus;
import fa.training.entities.converter.SeatStatusConverter;

import javax.persistence.*;

@Getter
@Setter
@ToString
@Entity
@Table(name="SEAT")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Seat {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="SEAT_ID")
    private Integer seatId;

    @Column(name="SEAT_ROW", nullable = false)
    private String seatRow;

    @Column(name="SEAT_COLUMN",nullable = false)
    private String seatColumn;

    @Convert(converter = SeatStatusConverter.class)
    @Column(name="SEAT_STATUS",nullable = false)
    private SeatStatus seatStatus;

    @Convert(converter = SeatTypeConverter.class)
    @Column(name="SEAT_TYPE",nullable = false)
    private SeatType seatType;

    @ManyToOne
    @JoinColumn(name="CINEMA_ROOM_ID")
    private CinemaRoom cinemaRoom;
}
