package fa.training.entities.converter;

import fa.training.enums.SeatType;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class SeatTypeConverter implements AttributeConverter<SeatType, String> {


    @Override
    public String convertToDatabaseColumn(SeatType seatType) {
       switch (seatType){
           case VIP:
               return "vip";
           case NORMAL:
               return "normal";
           default:
               return null;
       }
    }

    @Override
    public SeatType convertToEntityAttribute(String s) {
        switch (s){
            case "vip":
                return SeatType.VIP;
            case "normal":
                return SeatType.NORMAL;
            default:
                return null;
        }
    }
}
