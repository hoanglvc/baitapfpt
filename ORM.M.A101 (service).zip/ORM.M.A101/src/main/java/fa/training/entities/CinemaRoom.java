package fa.training.entities;

import lombok.*;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@ToString
@Entity
@Table(name = "CINEMA_ROOM")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@NamedQueries({@NamedQuery(name = "cinemas", query = "from CinemaRoom")})
public class CinemaRoom {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CINEMA_ROOM_ID")
    private Integer cinemaRoomId;

    @Column(name = "CINEMA_ROOM_NAME", unique = true, nullable = false)
    private String cinemaRoomName;

    @Column(name = "SEAT_QUANTITY", nullable = false)
    private Integer seatQuantity;

    @OneToOne(mappedBy = "cinemaRoom", cascade = CascadeType.ALL)
    @ToString.Exclude
    private CinemaRoomDetail cinemaRoomDetail;

    @OneToMany(mappedBy = "cinemaRoom", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @ToString.Exclude
    private Set<Seat> seats;


//    public CinemaRoom(Integer cinemaRoomId, String cinemaRoomName) {
//        this.cinemaRoomId = cinemaRoomId;
//        this.cinemaRoomName = cinemaRoomName;
//    }
}
