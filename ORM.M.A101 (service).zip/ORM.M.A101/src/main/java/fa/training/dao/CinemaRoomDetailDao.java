package fa.training.dao;

import fa.training.dao.BaseDao;
import fa.training.entities.CinemaRoomDetail;

public interface CinemaRoomDetailDao extends BaseDao<CinemaRoomDetail, Integer> {
}
