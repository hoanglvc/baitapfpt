package fa.training.dao.impl;

import fa.training.dao.CinemaRoomDao;
import fa.training.entities.CinemaRoom;
import fa.training.utils.HibernateUtils;
import org.hibernate.Session;

import javax.persistence.Query;
import javax.persistence.criteria.*;
import java.util.List;

public class CinemaRoomDaoImpl extends BaseDaoImpl<CinemaRoom, Integer> implements CinemaRoomDao {

    public CinemaRoomDaoImpl() {
        super(CinemaRoom.class);
    }

}
