package fa.training.dao;

import fa.training.entities.Seat;

public interface SeatDao extends BaseDao<Seat,Integer> {


}
