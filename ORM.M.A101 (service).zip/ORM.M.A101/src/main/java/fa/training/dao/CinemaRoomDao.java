package fa.training.dao;

import fa.training.entities.CinemaRoom;

import java.util.List;

public interface CinemaRoomDao extends BaseDao<CinemaRoom, Integer> {


}
