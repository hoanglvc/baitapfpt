package fa.training.dao.impl;

import fa.training.dao.MovieDao;
import fa.training.entities.Movie;

public class MovieDaoImpl extends BaseDaoImpl<Movie, Integer> implements MovieDao {
    public MovieDaoImpl() {
        super(Movie.class);
    }


}
