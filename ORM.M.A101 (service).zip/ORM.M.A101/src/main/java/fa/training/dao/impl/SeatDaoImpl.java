package fa.training.dao.impl;

import fa.training.dao.SeatDao;
import fa.training.entities.Seat;

public class SeatDaoImpl extends BaseDaoImpl<Seat, Integer> implements SeatDao {

    public SeatDaoImpl() {
        super(Seat.class);
    }
}
