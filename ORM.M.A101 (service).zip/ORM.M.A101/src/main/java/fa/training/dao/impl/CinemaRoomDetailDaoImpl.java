package fa.training.dao.impl;

import fa.training.dao.CinemaRoomDetailDao;
import fa.training.entities.CinemaRoomDetail;

public class CinemaRoomDetailDaoImpl extends BaseDaoImpl<CinemaRoomDetail, Integer>
                                        implements CinemaRoomDetailDao {
    public CinemaRoomDetailDaoImpl() {
        super(CinemaRoomDetail.class);
    }
}
