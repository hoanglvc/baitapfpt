package fa.training.dao;

import fa.training.entities.Movie;
import fa.training.entities.Seat;

import java.util.List;

public interface MovieDao extends BaseDao<Movie, Integer> {

}
