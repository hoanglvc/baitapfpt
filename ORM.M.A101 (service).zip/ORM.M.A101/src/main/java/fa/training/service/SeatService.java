package fa.training.service;

import fa.training.dao.SeatDao;
import fa.training.entities.Seat;

import java.util.List;

public interface SeatService{

    Integer save(Seat seat);

    List<Seat> getAll();

    Seat getOne(Integer integer);

    void update(Seat seat);

    void delete(Integer integer);
}
