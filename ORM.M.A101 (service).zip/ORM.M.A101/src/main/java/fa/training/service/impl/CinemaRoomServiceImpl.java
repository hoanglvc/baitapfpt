package fa.training.service.impl;

import fa.training.dao.CinemaRoomDao;
import fa.training.entities.CinemaRoom;
import fa.training.service.CinemaRoomService;

import java.util.List;

public class CinemaRoomServiceImpl implements CinemaRoomService {

    private final CinemaRoomDao cinemaRoomDao;

    public CinemaRoomServiceImpl(CinemaRoomDao cinemaRoomDao){
        this.cinemaRoomDao = cinemaRoomDao;
    }

    @Override
    public Integer save(CinemaRoom cinemaRoom) {
        return cinemaRoomDao.save(cinemaRoom);
    }

    @Override
    public List<CinemaRoom> getAll() {
        return cinemaRoomDao.getAll();
    }

    @Override
    public CinemaRoom getOne(Integer id) {
        return cinemaRoomDao.getOne(id);
    }

    @Override
    public void update(CinemaRoom cinemaRoom) {
        cinemaRoomDao.update(cinemaRoom);
    }

    @Override
    public void delete(Integer integer) {
        cinemaRoomDao.delete(integer);
    }
}
