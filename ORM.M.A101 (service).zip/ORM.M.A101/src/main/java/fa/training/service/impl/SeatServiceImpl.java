package fa.training.service.impl;

import fa.training.dao.CinemaRoomDao;
import fa.training.dao.SeatDao;
import fa.training.entities.CinemaRoom;
import fa.training.entities.Seat;
import fa.training.exception.CinemaRoomCapacityException;
import fa.training.service.CinemaRoomService;
import fa.training.service.SeatService;

import java.util.List;
import java.util.Set;

public class SeatServiceImpl implements SeatService {

    private final SeatDao seatDao;

    private final CinemaRoomDao cinemaRoomDao;

    public SeatServiceImpl(CinemaRoomDao cinemaRoomDao, SeatDao seatDao){
        this.cinemaRoomDao  = cinemaRoomDao;
        this.seatDao = seatDao;
    }

    @Override
    public Integer save(Seat seat) throws CinemaRoomCapacityException {
        CinemaRoom cinemaRoom = seat.getCinemaRoom();
        Set<Seat> seats = cinemaRoom.getSeats();
        if(seats.size() >= cinemaRoom.getSeatQuantity()){
            throw new CinemaRoomCapacityException(String.format("Save exception " +
                                                                "because CinemaRoom's seat quantity capacity is full: Max is %d, Current is %d",
                                                                cinemaRoom.getCinemaRoomId(),
                                                                cinemaRoom.getSeatQuantity(),
                                                                seats.size()));
        }
        return seatDao.save(seat);
    }

    @Override
    public List<Seat> getAll() {
        return seatDao.getAll();
    }

    @Override
    public Seat getOne(Integer id) {
        return seatDao.getOne(id);
    }

    @Override
    public void update(Seat seat) {
        seatDao.update(seat);
    }

    @Override
    public void delete(Integer id) {
        seatDao.delete(id);
    }
}
