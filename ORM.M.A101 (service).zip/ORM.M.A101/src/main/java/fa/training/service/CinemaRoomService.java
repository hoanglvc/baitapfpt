package fa.training.service;

import fa.training.dao.CinemaRoomDao;
import fa.training.entities.CinemaRoom;

import java.util.List;

public interface CinemaRoomService{

    Integer save(CinemaRoom cinemaRoom);

    List<CinemaRoom> getAll();

    CinemaRoom getOne(Integer integer);

    void update(CinemaRoom cinemaRoom);

    void delete(Integer integer);
}
