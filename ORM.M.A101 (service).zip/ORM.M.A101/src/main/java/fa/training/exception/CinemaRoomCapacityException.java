package fa.training.exception;

public class CinemaRoomCapacityException extends RuntimeException {

    public CinemaRoomCapacityException() {
        super();
    }

    public CinemaRoomCapacityException(String message) {
        super(message);
    }

    public CinemaRoomCapacityException(String message, Throwable cause) {
        super(message, cause);
    }

    public CinemaRoomCapacityException(Throwable cause) {
        super(cause);
    }

    protected CinemaRoomCapacityException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
