package fa.training.enums;

public enum SeatStatus {

    AVAILABLE, NOT_AVAILABLE, BOOKED;

}
