package fa.training.enums;

public enum SeatType{

    VIP, NORMAL;


}
