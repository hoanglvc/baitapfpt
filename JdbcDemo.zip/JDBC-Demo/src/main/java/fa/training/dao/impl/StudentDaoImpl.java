package fa.training.dao.impl;

import fa.training.dao.StudentDao;
import fa.training.entites.Class;
import fa.training.entites.Student;
import fa.training.utils.JdbcConnection;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;

public class StudentDaoImpl implements StudentDao {
    @Override
    public boolean save(Student student) throws SQLException {
        try(Connection connection = JdbcConnection.getConnection()) {
            String sql = "insert into student(name, dob, class_id) values (?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, student.getName());
            preparedStatement.setDate(2, Date.valueOf(student.getDob()));
            if(student.getClassId() != null ){
                preparedStatement.setInt(3, student.getClassId());
            }else {
                preparedStatement.setNull(3, Types.INTEGER);
            }


            int affectedRow = preparedStatement.executeUpdate();
            return affectedRow == 1;
        }
    }

    @Override
    public List<Student> findAll() throws SQLException {
        try(Connection connection = JdbcConnection.getConnection()) {
            List<Student> students = new LinkedList<>();
            String sql = "select * from student";
            Statement statement = connection.createStatement();

            ResultSet rs = statement.executeQuery(sql);
            while (rs.next()){
                students.add(new Student(rs.getInt("id"),
                                            rs.getString("name"),
                                            rs.getDate("dob").toLocalDate(),
                        (Integer) rs.getObject("class_id")));
            }
            return students;
        }
    }

    @Override
    public Class findOne(Integer id) throws SQLException {
        return null;
    }

    @Override
    public boolean update(Student student) throws SQLException {
        return false;
    }

    @Override
    public boolean delete(Integer id) throws SQLException {
        try(Connection connection = JdbcConnection.getConnection()) {
            String sql = "delete from student where id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, id);

            int affectedRow = statement.executeUpdate();

            return affectedRow == 1;
        }
    }

    @Override
    public void setClassNull(Integer classId) throws SQLException {
        try(Connection connection = JdbcConnection.getConnection()) {
            String sql = "update student set class_id = NULL where class_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, classId);

            statement.executeUpdate();

        }
    }

    public static void main(String[] args) throws SQLException {
        StudentDao studentDao = new StudentDaoImpl();
        studentDao.setClassNull(3);
    }
}
