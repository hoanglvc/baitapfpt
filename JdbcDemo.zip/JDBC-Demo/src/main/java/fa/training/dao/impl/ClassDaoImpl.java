package fa.training.dao.impl;

import fa.training.entites.Class;
import fa.training.utils.JdbcConnection;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;

public class ClassDaoImpl implements fa.training.dao.ClassDao {

    @Override
    public boolean save(Class clazz) throws SQLException {
        try(Connection connection = JdbcConnection.getConnection()) {
            String sql = "insert into class(name) values (?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, clazz.getName());

            int affectedRow = preparedStatement.executeUpdate();
            return affectedRow == 1;
        }
    }

    @Override
    public List<Class> findAll() throws SQLException{
        try(Connection connection = JdbcConnection.getConnection()) {
            List<Class> classes = new LinkedList<>();
            String sql = "select * from class";
            Statement statement = connection.createStatement();

            ResultSet rs = statement.executeQuery(sql);
            while (rs.next()){
                classes.add(new Class(rs.getInt("id"),
                                        rs.getString("name")));
            }
            return classes;
        }
    }

    @Override
    public Class findOne(Integer id) throws SQLException {
        try(Connection connection = JdbcConnection.getConnection()) {
            String sql = "select * from class where id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, id);

            ResultSet rs = statement.executeQuery();
            if(rs.next()){
                return new Class(rs.getInt("id"), rs.getString("name"));
            }
            return null;
        }
    }

    @Override
    public boolean update(Class clazz) {
        return false;
    }

    @Override
    public boolean delete(Integer id) throws SQLException{
        try(Connection connection = JdbcConnection.getConnection()) {
            String sql = "delete from class where id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, id);

            int affectedRow = statement.executeUpdate();

            return affectedRow == 1;
        }
    }
}
