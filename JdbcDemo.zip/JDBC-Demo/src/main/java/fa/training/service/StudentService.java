package fa.training.service;

import fa.training.entites.Class;
import fa.training.entites.Student;

import java.sql.SQLException;
import java.util.List;

public interface StudentService {
    boolean save(Student student) throws SQLException;

    List<Student> findAll() throws SQLException;

    Class findOne(Integer id) throws SQLException;

    boolean update(Student student) throws SQLException;

    boolean delete(Integer id) throws SQLException;
}
