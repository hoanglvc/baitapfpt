package fa.training.service.impl;

import fa.training.dao.StudentDao;
import fa.training.dao.impl.StudentDaoImpl;
import fa.training.entites.Class;
import fa.training.entites.Student;
import fa.training.service.StudentService;

import java.sql.SQLException;
import java.util.List;

public class StudentServiceImpl implements StudentService {

    private StudentDao studentDao;

    public StudentServiceImpl(StudentDao studentDao){
        this.studentDao = studentDao;
    }

    @Override
    public boolean save(Student student) throws SQLException {
        return studentDao.save(student);
    }

    @Override
    public List<Student> findAll() throws SQLException {
        return studentDao.findAll();
    }

    @Override
    public Class findOne(Integer id) throws SQLException {
        return null;
    }

    @Override
    public boolean update(Student student) throws SQLException {
        return false;
    }

    @Override
    public boolean delete(Integer id) throws SQLException {
        return false;
    }
}
