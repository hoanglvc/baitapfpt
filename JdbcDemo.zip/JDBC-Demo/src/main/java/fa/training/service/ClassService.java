package fa.training.service;

import fa.training.entites.Class;

import java.sql.SQLException;
import java.util.List;

public interface ClassService {

    boolean save(Class clazz) throws SQLException;

    List<Class> findAll() throws SQLException;

    Class findOne(Integer id) throws SQLException;

    boolean update(Class clazz) throws SQLException;

    boolean delete(Integer id) throws SQLException;
}
