package fa.training.service.impl;

import fa.training.dao.ClassDao;
import fa.training.dao.StudentDao;
import fa.training.entites.Class;
import fa.training.service.ClassService;

import java.sql.SQLException;
import java.util.List;

public class ClassServiceImpl implements ClassService {

    private ClassDao classDao;

    private StudentDao studentDao;

    public ClassServiceImpl(ClassDao classDao, StudentDao studentDao){
        this.classDao = classDao;
        this.studentDao = studentDao;
    }

    @Override
    public boolean save(Class clazz) throws SQLException {
        return classDao.save(clazz);
    }

    @Override
    public List<Class> findAll() throws SQLException {
        return classDao.findAll();
    }

    @Override
    public Class findOne(Integer id) throws SQLException {
        return classDao.findOne(id);
    }

    @Override
    public boolean update(Class clazz) throws SQLException {
        return classDao.update(clazz);
    }

    @Override
    public boolean delete(Integer id) throws SQLException {
        //delete 1 cai class, thi set null cho tat ca cac student thuoc ve class do
        studentDao.setClassNull(id);

        //delete 1 cai class, thi khu luon nhung tk thuoc ve lop day
        //cach 1: find all student co class id do, xong lap de goi ham delete voi tung tk student -> slower
        //cach 2: viet ham xoa student thuoc ve class id -> delete on db
        
        return classDao.delete(id);
    }
}
