package fa.training;


import fa.training.dao.ClassDao;
import fa.training.dao.StudentDao;
import fa.training.dao.impl.ClassDaoImpl;
import fa.training.dao.impl.StudentDaoImpl;
import fa.training.entites.Student;
import fa.training.service.ClassService;
import fa.training.service.StudentService;
import fa.training.service.impl.ClassServiceImpl;
import fa.training.service.impl.StudentServiceImpl;
import fa.training.utils.Constant;
import fa.training.utils.InputUtils;

import java.sql.SQLException;


public class StudentManagement {
    public static void main(String[] args) throws SQLException {
        StudentService studentService = new StudentServiceImpl(new StudentDaoImpl());
        ClassService classService = new ClassServiceImpl(new ClassDaoImpl(), new StudentDaoImpl());


        //Save class
        //Step 1: Input class
//        Class clazz = new Class();
//        clazz.setName(InputUtils.inputString("Enter class name: "));
//        //Step 2: Call service
//        //Step 3: Return message
//        try{
//            System.out.println(classDao.save(clazz) ? "Save success" : "Save fail");
//        }catch (SQLException e){
//            System.out.println(e.getMessage());
//        }

        //Save student
//        Student student = new Student();
//        student.setName(InputUtils.inputString("Enter name: "));
//        student.setDob(InputUtils.inputDate("Enter dob: ", "Wrong format", Constant.DATE_FORMAT));
//
//        Integer classId = InputUtils.inputInt("Enter class id: ", "");
////        while (classDao.findOne(classId) == null) {
////            System.out.println("Class Id not found");
////            classId = InputUtils.inputInt("Enter class id: ", "");
////        }
//        if(classDao.findOne(classId) == null){
//            student.setClassId(null);
//        }else {
//            student.setClassId(classId);
//        }
//
//        try {
//            System.out.println(studentDao.save(student) ? "Save success" : "Save ");
//        } catch (SQLException e) {
//            System.out.println(e.getMessage());
//        }
//
//        System.out.println(studentDao.findAll());
        classService.delete(3);

    }

}
