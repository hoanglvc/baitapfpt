package fa.training.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class InputUtils {
    private static Scanner scanner = new Scanner(System.in);

    public static int inputInt(String label, String errorMessage) {
        while (true) {
            try {
                System.out.println(label);
                int value = Integer.parseInt(scanner.nextLine());
                return value;
            } catch (NumberFormatException e) {
                System.err.println(errorMessage);
            }
        }
    }

    public static double inputDouble(String label, String errorMessage) {
        while (true) {
            try {
                System.out.println(label);
                double value = Double.parseDouble(scanner.nextLine());
                return value;
            } catch (NumberFormatException e) {
                System.err.println(errorMessage);
            }
        }
    }

    public static long inputLong(String label, String errorMessage) {
        while (true) {
            try {
                System.out.println(label);
                long value = Long.parseLong(scanner.nextLine());
                return value;
            } catch (NumberFormatException e) {
                System.err.println(errorMessage);
            }
        }
    }

    public static float inputFloat(String label, String errorMessage) {
        while (true) {
            try {
                System.out.println(label);
                float value = Integer.parseInt(scanner.nextLine());
                return value;
            } catch (NumberFormatException e) {
                System.err.println(errorMessage);
            }
        }
    }
    public static String inputString(String label) {
        System.out.println(label);
        return scanner.nextLine();
    }

    public static LocalDate inputDate(String label, String errorMessage, String datePattern) {
        while (true) {
            try {
                DateTimeFormatter dmt = DateTimeFormatter.ofPattern(datePattern);
                System.out.println(label + "("+datePattern+")");
                String value = scanner.nextLine();
                LocalDate date = LocalDate.parse(value, dmt);
                return date;
            } catch (DateTimeParseException e) {
                System.err.println(errorMessage + "(" + datePattern + ")");
            }
        }
    }

}
