package fa.training.utils;

public class Constant {

    public static final String DATE_FORMAT = "dd/MM/yyyy";
    public static final String DB_USERNAME = "sa"; //insert your db username
    public static final String DB_PASSWORD = "Password.1"; //insert your db password
    public static final String DB_SQL_SERVER_CONNECTION_URL = "jdbc:sqlserver://localhost:1433;databaseName=crud";
}
